# Migration Report

## Completed

- Replaced the Tkinter main shell with a PySide6 enterprise UI.
- Removed the Quick Access landing card.
- Added layered package structure under `app/`.
- Added PySide6 password dialog preserving the original password-only workflow.
- Recreated the original PowerBuilder menu hierarchy from `pbl/gminestr/m_mainmenu.srm`.
- Added left module explorer, tabbed workspace, toolbar, status bar, and light/dark themes.
- Added SQLAlchemy model base, repository layer, services layer, and Alembic scaffold.
- Added master CRUD pages using `QTableView` and `QAbstractTableModel`.
- Converted the **Sales Billing** module (`gminet1/w_sales.srw`) into a real
  business form — not a generic table editor:
  - `app/services/sales_service.py` — faithful port of the per-line and bill-total
    math (net wt, wastage, making charge, stone, CGST/SGST/IGST split, round-off)
    using `Decimal`.
  - `app/repositories/sales_repository.py` — customer/item lookups, current rates,
    bill-number generation (`salestype` prefix + `generals.SBLEN`), and atomic
    header+detail save/load to `salesm`/`salesd` (portable SQL Anywhere/SQLite).
  - `app/presentation/sales_billing.py` — modern PySide6 form: header card,
    editable line grid with live recompute, totals panel, open/new/save/print.
  - `app/reports/invoice.py` — reportlab tax-invoice / estimate PDF with
    amount-in-words.
  - Wired into the **Sales** menu and sidebar shortcut via `main_window`.
  - Verified end-to-end against a temp DB (lookup → save → reload) and with a
    worked calculation example.

## Remaining Conversion

Transaction, report, barcode, accounting, manufacturing, and repair workflows require detailed object-by-object conversion from PB windows, DataWindows, functions, and embedded SQL.
