# Jewellery ERP Enterprise

Modern PySide6 migration shell for the PowerBuilder Jewellery ERP.

## Run

```bat
cd "E:\FI916\jewellery erp software"
pip install -r requirements.txt
python main.py
```

or double-click `run.bat`.

## Build

```bat
pyinstaller --onefile --windowed --name JewelleryERP main.py
```

or:

```bat
pyinstaller pyinstaller.spec
```

## Architecture

- Presentation: `app/presentation` using PySide6
- Services: `app/services`
- Repositories: `app/repositories`
- Models: `app/models` using SQLAlchemy 2.x
- Auth: `app/auth`
- Reports: `app/reports`

The original PowerBuilder menu is read from `E:\FI916\pbl\gminestr\m_mainmenu.srm`.
Quick Access has been removed. Users work from the full ERP menu, module
explorer, and tabbed workspace.

## Database

Connection settings live in `db_config.ini`. The current configuration targets
SQL Anywhere through ODBC and reuses the existing ERP database.
